from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.api.routes import router
from app.config import settings
from app.db import Base, engine

Base.metadata.create_all(bind=engine)
app = FastAPI(title=settings.app_name, version="0.2.0", description="Evidence-first stock intelligence API: SEC, market, X, trusted news, clustering and signal scoring.")
app.include_router(router)
static_dir = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get("/")
def root():
    return {"name": settings.app_name, "version": "0.2.0", "docs": "/docs", "dashboard": "/dashboard", "guardrail": "Scores measure evidence/activity strength, not expected return."}

@app.get("/dashboard", include_in_schema=False)
def dashboard():
    return FileResponse(static_dir / "index.html")
